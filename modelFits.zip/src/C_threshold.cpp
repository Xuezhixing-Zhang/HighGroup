#include <RcppArmadillo.h>
#include "coord_functions.h"
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_threshold_vec(arma::vec t, arma::vec lambda) {
  int n = t.size();
  arma::vec result(n);
  for(int i = 0; i < n; i++){
    double abs_t = std::abs(t[i]);
    result[i] = (abs_t - lambda[i]) > 0 ? (abs_t - lambda[i]) * (t[i] >= 0 ? 1 : -1) : 0;
  }
  return result;
}

// [[Rcpp::export]]
arma::vec C_threshold_scalar(arma::vec t, double lambda) {
  int n = t.size();
  arma::vec result(n);
  for(int i = 0; i < n; i++){
    double abs_t = std::abs(t[i]);
    result[i] = (abs_t - lambda) > 0 ? (abs_t - lambda) * (t[i] >= 0 ? 1 : -1) : 0;
  }
  return result;
}
