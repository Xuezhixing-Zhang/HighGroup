// coord_functions.h

#ifndef coord_functions_H
#define coord_functions_H

#include <RcppArmadillo.h>

arma::vec C_threshold_scalar(arma::vec t, double lambda);
arma::vec C_threshold_vec(arma::vec t, arma::vec lambda);
arma::vec C_updatemu(arma::vec& mu_est, double& Lambda_max_mu, arma::mat& denom, arma::vec& derivative, double alpha);
arma::vec C_numeratorComputation(int& n, arma::vec& eta_est, arma::vec& v_est, double& Theta, arma::sp_mat& deltas);
arma::vec C_updatemu_QP(arma::vec& mu_est, double& Lambda_max_mu, double& Theta, arma::vec& c1, arma::sp_mat& Q2, arma::vec& c2, arma::mat& Amat, arma::mat& bvec);

#endif // coord_functions_H



