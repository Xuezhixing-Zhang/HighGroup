#include <RcppArmadillo.h>
#include "coord_functions.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
Rcpp::List C_coordinateDescent(arma::vec& Y,
                             arma::mat& Z,
                             int& n,
                             arma::vec& beta0,
                             arma::vec& mu0,
                             std::string& method,
                             arma::vec& eta_est,
                             double& epsilon_est,
                             arma::vec& v_est,
                             double& Theta,
                             double& Lambda,
                             double& Delta,
                             double& Gamma,
                             double& Lambda_max_mu,
                             arma::mat& denom,
                             arma::sp_mat& deltas,
                             double& alpha) {
  
  // Get beta, mu, eta
  arma::sp_vec beta_est;
  arma::vec beta_est_vec;
  
  double beta_norm_diff_now = 2;
  double mu_norm_diff_now = 2;
  double beta_norm_diff_prev = 1;
  double mu_norm_diff_prev = 1;
  
  if (beta0.is_empty()) {
    beta_est = arma::ones<arma::vec>(Z.n_cols);
  } else {
    beta_est = beta0;
  }
  
  // Set an iteration threshold
  double iter_max = 200000; 
  // Initialize iteration counter
  double iter_count = 0;

  arma::vec mu_est = mu0;
  
  // Initialize beta.prev and beta.now
  arma::sp_vec beta_prev = beta_est;
  arma::sp_vec beta_now = beta_est + 100;
  arma::vec mu_prev = mu_est;
  arma::vec mu_now = mu_est + 100;
  
  // Calculate part of the numerator for updating mu
  arma::vec numerator = C_numeratorComputation(n, eta_est, v_est, Theta, deltas);
  arma::sp_mat deltas2 = deltas.t() * deltas;
  arma::uvec indices = arma::linspace<arma::uvec>(0, Z.n_cols - 1, Z.n_cols);
  double p = Z.n_cols;
  arma::vec Zj;
  arma::vec beta_no_j;
  arma::vec sum_beta_Z_no_j;
  arma::vec Z_beta;

  // For update mu
  arma::mat Amat(2*n, n+1, arma::fill::zeros);  
  arma::vec bvec(2*n, arma::fill::zeros);
  
  // For mu_i <= t
  for(int i = 0; i < n; ++i) {
    Amat(i, i) = 1.0;
    Amat(i, n) = -1.0;
  }
  
  // For -mu_i <= t
  for(int i = n; i < 2*n; ++i) {
    Amat(i, i-n) = -1.0;
    Amat(i, n) = -1.0;
  }


  // Coordinate descent
  while ((arma::norm(beta_prev - beta_now, 2)/arma::norm(beta_prev, 2) > 1e-03 || 
  arma::norm(mu_prev - mu_now, 2)/arma::norm(mu_prev, 2) > 1e-03) && 
  iter_count < iter_max) {

    beta_prev = beta_est;
    mu_prev = mu_est;

    for (int j = 0; j < static_cast<int>(Z.n_cols); j++) {

      beta_no_j = beta_est;
      beta_no_j.shed_row(j);
      indices.shed_row(j);
      Zj = Z.col(j);
      
      if (j == 0 && iter_count == 0){

        Z_beta = Z * beta_est;
        sum_beta_Z_no_j = Z_beta - Zj * beta_est[j];

      }
      else if (j == 0){
        
        sum_beta_Z_no_j = sum_beta_Z_no_j + Z.col(p-1) * beta_est[p-1] - Zj * beta_est[j];

      }
      else{
    
        sum_beta_Z_no_j = sum_beta_Z_no_j + Z.col(j-1) * beta_est[j-1] - Zj * beta_est[j];

      }
      

      if (method == "L1") {
        
          arma::vec value(1);
          value[0] = as_scalar(Zj.t() * (Y - mu_est - sum_beta_Z_no_j));
          
          arma::vec denom_1(1);
          denom_1[0] = as_scalar(Zj.t() * Zj + Theta + (1-alpha) * Lambda);
          
          beta_est[j] = C_threshold_scalar((value - Theta * (sum(beta_no_j) + epsilon_est / Theta)), alpha * Lambda)[0] / (denom_1[0]);
          
        } else {
          // Add a ridge for this penalty.

          
          // Calculate the values we need.
          arma::vec R_no_j = Y - mu_est - sum_beta_Z_no_j;
          double T_no_j = sum(beta_no_j) + epsilon_est / Theta;
          double sum_R_no_j_Zj = as_scalar(Zj.t() * R_no_j);
          double denom_j = as_scalar(Zj.t() * Zj) + Theta + (1 - alpha) * Lambda;

          arma::vec value(1);
          value[0] = (sum_R_no_j_Zj - Theta * T_no_j) / denom_j;

          if (method == "MCP") {
            if (std::abs(value[0]) <= Gamma * alpha * Lambda) {
              beta_est[j] = C_threshold_scalar(value, alpha * Lambda / denom_j)[0] / (1 - 1 / (Gamma * denom_j));
            } else {
              beta_est[j] = value[0];
            }
          } else { // method == "SCAD"
            if (std::abs(value[0]) <= alpha * Lambda + alpha * Lambda / denom_j) {
              beta_est[j] = C_threshold_scalar(value, alpha * Lambda / denom_j)[0];
            } else if (std::abs(value[0]) > Gamma * alpha * Lambda) {
              beta_est[j] = value[0];
            } else {
              beta_est[j] = C_threshold_scalar(value, Gamma * alpha * Lambda / ((Gamma - 1) * denom_j))[0] / (1 - 1 / ((Gamma - 1) * denom_j));
            }
          }
        }

        indices.insert_rows(j, 1);
        indices[j] = j;
      }

      if (Lambda_max_mu == 0){
        // Estimate mu_est withour max penalty
        mu_est = arma::solve(denom, Y - Z * beta_est + numerator);
      }
      else{
        // Estimate mu_est with max penalty, using subgradient method
        // To specify step length, you need to manually change the alpha.
        //double alpha = 0.00001;
        //arma::vec derivative = Y - Z * beta_est + numerator;
        //mu_est = C_updatemu(mu_est, Lambda_max_mu, denom, derivative, alpha);
        arma::vec c1 = Y - Z * beta_est;
        //Rcpp::Rcout << "itr: " << iter_count << std::endl;
        mu_est = C_updatemu_QP(mu_est, Lambda_max_mu, Theta, c1, deltas2, numerator, Amat, bvec);

      }

      beta_now = beta_est;
      mu_now = mu_est;

      // Increase iteration counter
      iter_count++;
    }

    if(iter_count >= iter_max){
    Rcpp::warning("Maximum number of iterations reached before convergence.");
  }
    beta_est_vec = arma::vec(beta_est);
    Rcpp::List result = Rcpp::List::create(Rcpp::Named("beta.est") = beta_est_vec,
                                           Rcpp::Named("mu.est") = mu_est,
                                           Rcpp::Named("eta.est") = eta_est);
    return result;
}