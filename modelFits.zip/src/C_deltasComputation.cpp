#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::sp_mat C_deltasComputation(int& n) {
  
  arma::sp_mat delta(n, n*(n-1)/2);

  for(int i = 0; i < n-1; i++){
    for(int j = i+1; j < n; j++){
      
      delta(i, (i * (n-1) - (i - 1) * i / 2) + j - i - 1) = 1;
      delta(j, (i * (n-1) - (i - 1) * i / 2) + j - i - 1) = -1;
    }
  }
  
  return delta.t();
}