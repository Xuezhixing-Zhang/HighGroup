#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_etaComputation(arma::sp_mat& deltas, arma::vec& mu) {
  
  arma::vec eta_est = deltas * mu;
  
  return eta_est;
}