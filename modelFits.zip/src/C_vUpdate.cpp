#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_vUpdate(arma::vec& v_est, 
                  arma::vec& mu_delta, 
                  arma::vec& eta_est, 
                  double& Theta) {
  
  arma::vec x = v_est + Theta * (mu_delta - eta_est);
  
  return x;
}