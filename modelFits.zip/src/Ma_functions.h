// Ma_functions.h

#ifndef Ma_function_H
#define Ma_function_H

#include <RcppArmadillo.h>

arma::vec C_threshold_scalar(arma::vec t, double lambda);
arma::vec C_threshold_vec(arma::vec t, arma::vec lambda);
arma::mat C_numeratorComputation(int& n, arma::vec& eta_est, arma::vec& v_est, double& Theta, arma::sp_mat& deltas);
arma::mat C_IDeltaComputation(int& n, double& Theta, double& Lambda_2);
arma::mat C_deltasComputation(int& n);
arma::vec C_etaComputation(arma::sp_mat& deltas, arma::vec& mu);
arma::vec C_etaUpdate(std::string& method, arma::vec& v_est, arma::vec& weight_mu, arma::vec& eta_est, arma::vec& mu_delta, arma::sp_mat& deltas, double& Theta,  double& Gamma,  double& Delta, double& Lambda_max, arma::vec& Y, double& phi);
arma::vec C_vUpdate(arma::vec& v_est, arma::vec& mu_delta, arma::vec& eta_est, double& Theta);


#endif // Ma_function_H