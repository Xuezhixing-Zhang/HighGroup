#include <RcppArmadillo.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_updatemu_QP(arma::vec& mu_est, double& Lambda_max_mu, double& Theta, arma::vec& c1, arma::sp_mat& Q2, arma::vec& c2, arma::mat& Amat, arma::mat& bvec){

  Rcpp::Environment quadprog_pkg = Rcpp::Environment::namespace_env("quadprog");
  Rcpp::Function solve_qp = quadprog_pkg["solve.QP"];

  int n = mu_est.size();
  double t = arma::abs(mu_est).max();
  arma::mat Q1 = arma::eye<arma::mat>(n, n);
  arma::mat Dmat(n+1, n+1, arma::fill::zeros);
  Dmat.submat(0, 0, n-1, n-1) = Q1 + 0.5 * Theta * Q2;
  Dmat(n,n) = 1;
  arma::vec dvec(n + 1);
  dvec.subvec(0, n-1) = -1*(c1+c2);
  dvec(dvec.n_elem-1) = Lambda_max_mu;

  
  Rcpp::List result = solve_qp(Dmat, dvec, Amat.t(), bvec, 0, false);
  arma::vec mu_new = Rcpp::as<arma::vec>(result["solution"]);

  mu_new = mu_new.head(n);
  
  return mu_new;

}

