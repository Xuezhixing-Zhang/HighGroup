#include <RcppArmadillo.h>
#include "fit_functions.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
Rcpp::List C_modelFit_MaHuang(arma::vec& Y,
                      arma::mat& Z,
                      int& n,
                      int& p,
                      double& Theta,
                      double& Lambda,
                      double& Lambda_2,
                      double& Delta,
                      double& Gamma,
                      double& Lambda_max,
                      double& Lambda_max_mu,
                      std::string& method,
                      arma::vec& beta_est,
                      arma::vec& eta_est,
                      arma::vec& v_est,
                      arma::vec& mu_est,
                      arma::vec& weight_mu,
                      double& epsilon_est,
                      double& phi,
                      double& alpha,
                      arma::sp_mat& deltas) {

  // Initialize stop criterion
  arma::vec beta_prev = beta_est;
  arma::vec beta_now = beta_est + 1.0;
  arma::vec delta_mu_now = eta_est;
  arma::vec eta_now = eta_est + 1.0;
  arma::vec v_prev = v_est;
  arma::vec v_now = v_est + 1.0;
  arma::vec mu_now = mu_est + 1.0;

  arma::vec loss_iter(100000);
  arma::vec loss_penalized_iter(100000);
  arma::vec loss_all(100000);
  //arma::vec eta_iter(100000);
  //arma::vec v_iter(100000);
  // double epsilon_now = epsilon_est + 1.0;
  
  arma::mat denom = C_IDeltaComputation(n, Theta, Lambda_2);
  arma::mat I = arma::eye<arma::mat>(n, n);
  arma::mat Qx = Z * arma::inv(Z.t() * Z) * Z.t();
  int iterations = 0;
  
  while(arma::norm(beta_prev - beta_now, 2) >= 1e-06 ||
        arma::norm(delta_mu_now - eta_now, 2) >= 1e-06 ||
        arma::norm(v_prev - v_now, 2) >= 1e-06) {
        
    iterations += 1;
    beta_prev = beta_est;
    v_prev = v_est;
    
    //Rcpp::List cor_des_result = C_coordinateDescent(Y, Z, n, beta_est, mu_est, method,  eta_est, epsilon_est, v_est,Theta, Lambda, Delta, Gamma, Lambda_max_mu, denom, deltas, alpha);
    arma::mat numerator = C_numeratorComputation(n, eta_est, v_est, Theta, deltas);
    
    mu_est = arma::solve(denom - Qx, (I - Qx) * Y + numerator);
    beta_est = arma::solve(Z.t() * Z, Z.t() * (Y - mu_est));
    
    arma::vec mu_est_delta = deltas * mu_est;
    
    eta_est = C_etaUpdate(method, v_est, weight_mu, eta_est, mu_est_delta, deltas, Theta, Gamma, Delta, Lambda_max, Y, phi);
    epsilon_est = epsilon_est + Theta * arma::accu(beta_est);
    v_est = C_vUpdate(v_est, mu_est_delta, eta_est, Theta);

    //Calculate Loss functions:
    if(iterations >= 1 && iterations <= 100000) {
    loss_iter[iterations-1] = 0.5 * arma::sum(arma::square(Y - mu_est - Z * beta_est));
    arma::vec product = arma::exp(-phi * arma::square(deltas * Y)) % arma::abs(eta_est);
    loss_penalized_iter[iterations-1] = loss_iter[iterations-1] + alpha*Lambda * arma::sum(arma::abs(beta_est)) + Delta * arma::sum(product) + (1-alpha)*Lambda * arma::sum(arma::square(beta_est));
    loss_all[iterations-1] = loss_penalized_iter[iterations-1] + epsilon_est * arma::sum(beta_est) + arma::sum(v_est % (deltas * mu_est - eta_est)) + Theta/2.0 * std::pow(arma::sum(beta_est), 2) + Theta/2.0 * arma::sum(arma::square(deltas * mu_est - eta_est));
    //eta_iter[iterations-1] = arma::mean(arma::abs(eta_est - eta_now));
    //v_iter[iterations-1] = arma::mean(arma::abs(v_est - v_now));

    }

    
    beta_now = beta_est;
    // epsilon_now = epsilon_est;
    mu_now = mu_est;
    eta_now = eta_est;
    v_now = v_est;
    delta_mu_now = C_etaComputation(deltas, mu_est);
    
    // Rcpp::Rcout << "Iteration: " << iterations << std::endl;
    // Rcpp::Rcout << "First 10 values of mu: ";
    // for(int i = 0; i < std::min(10, (int)mu_est.size()); ++i) {
    //   Rcpp::Rcout << mu_est[i] << " ";
    // }
    // Rcpp::Rcout << std::endl;
  }

  loss_iter.resize(iterations);
  loss_penalized_iter.resize(iterations);
  loss_all.resize(iterations);
  // eta_iter.resize(iterations);
  // v_iter.resize(iterations);
  
  double residual = arma::accu(arma::square(Y - mu_est - Z * beta_est)) / n;
  Rcpp::Rcout << "Iteration: " << iterations << std::endl;
  // Return the result as a List
  return Rcpp::List::create(Rcpp::Named("beta.est") = beta_est,
                            Rcpp::Named("mu.est") = mu_est,
                            Rcpp::Named("eta.est") = eta_est,
                            Rcpp::Named("v.est") = v_est,
                            Rcpp::Named("epsilon.est") = epsilon_est,
                            Rcpp::Named("residual") = residual,
                            Rcpp::Named("iterations") = iterations,
                            Rcpp::Named("iterations") = iterations,
                            Rcpp::Named("loss_iter") = loss_iter,
                            Rcpp::Named("loss_penalized_iter_forL1") = loss_penalized_iter,
                            Rcpp::Named("loss_all_forL1") = loss_all);
}