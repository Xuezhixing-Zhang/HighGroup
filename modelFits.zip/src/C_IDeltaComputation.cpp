#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::mat C_IDeltaComputation(int& n, double& Theta, double& Lambda_2) {
  
  arma::mat I = arma::eye<arma::mat>(n, n);
  arma::mat oneM = arma::ones<arma::mat>(n, n);
  
  arma::mat result = (1 + 2 * Lambda_2 + n * Theta) * I - Theta * oneM;
  
  return result;
}


