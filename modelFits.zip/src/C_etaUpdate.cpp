#include <RcppArmadillo.h>
#include "coord_functions.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_etaUpdate(std::string& method,
                    arma::vec& v_est,
                    arma::vec& weight_mu,
                    arma::vec& eta_est,
                    arma::vec& mu_delta,
                    arma::sp_mat& deltas,
                    double& Theta, 
                    double& Gamma, 
                    double& Delta,
                    double& Lambda_max,
                    arma::vec& Y,
                    double& phi) {

  if (method == "L1") {
    arma::vec weight = arma::exp(-phi * arma::square(deltas * Y));
    eta_est = C_threshold_vec(mu_delta + v_est / Theta, weight * Delta / Theta);
  } 
  else if (method == "MCP") {
    
    // Adaptive MCP
    arma::vec weight;
    //if (weight_mu.is_empty()) {
    //    weight = arma::exp(-phi * arma::square(mu_delta));
    //} else {
    //    weight = weight_mu;
    //}
    
    weight = arma::exp(-phi * arma::square(weight_mu));
    // arma::vec intercepts = {-2, 2, 2, 2, -2, -2, -2, -2, 2, -2, -2, 2, -2, 2, 2, 2, -2, -2, -2, -2,
    //                      -2, -2, 2, -2, -2, -2, 2, 2, 2, 2, -2, -2, -2, -2, -2, -2, -2, -2, -2, 2,
    //                      -2, 2, 2, -2, 2, 2, -2, -2, 2, -2, -2, 2, -2, -2, 2, -2, -2, -2, 2, 2,
    //                      2, 2, 2, -2, 2, 2, 2, 2, -2, -2, -2, -2, 2, -2, 2, -2, -2, -2, -2, -2,
    //                      2, -2, -2, 2, -2, -2, 2, 2, -2, 2, 2, -2, -2, -2, -2, 2, -2, -2, -2, 2};
                          
    // arma::vec weight = arma::exp(-phi * arma::square(deltas * intercepts));
                          
    arma::vec Gamma_vec(weight.n_elem);
    Gamma_vec.fill(Gamma);

    Gamma_vec = arma::max(Gamma_vec, Gamma_vec / weight);

    arma::uvec indices1 = arma::find(arma::abs(mu_delta + v_est / Theta) <= Gamma_vec  % (weight * Delta));
    arma::uvec indices2 = arma::find(arma::abs(mu_delta + v_est / Theta) > Gamma_vec  % (weight * Delta));
    int indices3 = arma::abs(eta_est).index_max();
    int sign_eta = arma::sign(eta_est(indices3));

    eta_est.elem(indices1) = C_threshold_vec(mu_delta.elem(indices1) + v_est.elem(indices1) / Theta, weight.elem(indices1) * Delta / Theta) / (1 - 1 / (Gamma_vec.elem(indices1) * Theta));
    eta_est.elem(indices2) = mu_delta.elem(indices2) + v_est.elem(indices2) / Theta;
    eta_est(indices3) = eta_est(indices3) - sign_eta * Lambda_max/ Theta;
    
    

  } 
  else if (method == "SCAD") {
    arma::vec weight = arma::exp(-phi * arma::square(mu_delta));
    arma::vec Gamma_vec(weight.n_elem);
    Gamma_vec.fill(Gamma);

    Gamma_vec = arma::max(Gamma_vec, Gamma_vec / weight);

    arma::uvec indices1 = arma::find(arma::abs(mu_delta + v_est / Theta) <= (Delta * weight + Delta * weight / Theta));
    arma::uvec indices2 = arma::find(arma::abs(mu_delta + v_est / Theta) > Gamma_vec  % (weight * Delta));

    eta_est.elem(indices1) = C_threshold_vec(mu_delta.elem(indices1) + v_est.elem(indices1) / Theta, Delta * weight.elem(indices1) / Theta);
    eta_est.elem(indices2) = mu_delta.elem(indices2) + v_est.elem(indices2) / Theta;

    arma::uvec indices3 = arma::find(arma::abs(mu_delta + v_est / Theta) > (Delta * weight + Delta * weight / Theta) && arma::abs(mu_delta + v_est / Theta) <= Gamma_vec  % (weight * Delta));
    eta_est.elem(indices3) = C_threshold_vec(mu_delta.elem(indices3) + v_est.elem(indices3) / Theta, (Gamma_vec.elem(indices3)  % (weight.elem(indices3) * Delta)) / ((Gamma_vec.elem(indices3) - 1) * Theta)) / (1 - 1 / ((Gamma_vec.elem(indices3) - 1) * Theta));
  }

  return eta_est;
}