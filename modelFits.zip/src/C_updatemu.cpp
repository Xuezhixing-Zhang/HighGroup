#include <RcppArmadillo.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_updatemu(arma::vec& mu_est, double& Lambda_max_mu, arma::mat& denom, arma::vec& derivative, double alpha){

  // Subgradient Method
  arma::vec subgradient(mu_est.n_elem, arma::fill::zeros);
  arma::vec mu_prev = mu_est;
  arma::vec mu_now = mu_prev + 1;
  int itr_num = 0;

  //indices
  double max_abs_val = arma::abs(mu_est).max();
  arma::uvec indices = find(arma::abs(mu_est) == max_abs_val);
  int num_max_values = indices.size();
  arma::vec sign_mu_vec = arma::sign(mu_est(indices));

  while(arma::norm(mu_prev - mu_now, 2) > 1e-05 && itr_num< 200000){
    
    mu_prev = mu_est;

    // Get subgradient
    max_abs_val = arma::abs(mu_est).max();
    indices = find(arma::abs(mu_est) == max_abs_val);
    num_max_values = indices.size();
    sign_mu_vec = arma::sign(mu_est(indices));

    subgradient(indices) = 2 * Lambda_max_mu * sign_mu_vec / num_max_values;

    mu_est = mu_est - alpha*(denom * mu_est - derivative + subgradient);
    mu_now = mu_est;
    itr_num++;

    //if (itr_num >= 100000){
    //  Rcpp::Rcout << "MUnorm: " << arma::norm(mu_prev - mu_now, 2) << std::endl;
    //  Rcpp::Rcout << "MUitr_num: " << itr_num << std::endl;
    //  Rcpp::Rcout << "Num_Max: " << num_max_values << std::endl;
    //}
    
  }

  return mu_est;

}