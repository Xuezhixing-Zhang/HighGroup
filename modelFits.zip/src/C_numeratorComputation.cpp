#include <RcppArmadillo.h>
#include "coord_functions.h"
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec C_numeratorComputation(int& n, arma::vec& eta_est, arma::vec& v_est, double& Theta, arma::sp_mat& deltas) {
  
  arma::vec est = eta_est - v_est / Theta;
  arma::vec result = deltas.t() * est;
  
  return Theta * result;
}